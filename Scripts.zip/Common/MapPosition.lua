require 'MapPositionGOS'
--this file is deprecated