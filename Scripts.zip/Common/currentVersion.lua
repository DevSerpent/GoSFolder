Data = {
    Core = {
        Changelog = "Auto Version ChangeLog Here",
        Version = 0.02,
    },
    Champions = {
        Yone = {
            Changelog = "Yone Changelog Here",
            Version = 0.09,
        },
        Gangplank = {
            Changelog = "Gangplank Changelog Here",
            Version = 0.01,
        },
        LeeSin = {
            Changelog = "LeeSin Changelog Here",
            Version = 0.01,
        },
    },
    Loader = {
        Version = 0.01,
    },
}

return Data