Data = {
    Loader = {
        Version = 0.01,
    },
    
	Core = {
        Changelog = "Auto Version ChangeLog Here",
        Version = 0.02,
    },

    Champions = {
		
	Gangplank = {
            Changelog = "Gangplank Changelog Here",
            Version = 0.01,
        },
		
        LeeSin = {
            Changelog = "LeeSin Changelog Here",
            Version = 0.01,
        },		
		
        Yone = {
            Changelog = "Yone Changelog Here",
            Version = 0.09,
        },
    },
}

return Data
