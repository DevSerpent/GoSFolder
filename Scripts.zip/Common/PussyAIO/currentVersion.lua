Data = {
    Loader = {
        Version = 0.2,
    },
    Core = {
        Version = 0.21,
        Changelog = "Auto Version ChangeLog Here",
    },
    Champions = {
        Jinx = {
            Version = 0.06,
            Changelog = "Jinx Changelog Here",
        },
        Kayle = {
            Version = 0.04,
            Changelog = "Kayle Changelog Here",
        },
        Nidalee = {
            Version = 0.09,
            Changelog = "Nidalee Changelog Here",
        },
        Ryze = {
            Version = 0.13,
            Changelog = "Ryze Changelog Here",
        },
        Pyke = {
            Version = 0.05,
            Changelog = "Pyke Changelog Here",
        },
        Sett = {
            Version = 0.07,
            Changelog = "Sett Changelog Here",
        },
        Sylas = {
            Version = 0.08,
            Changelog = "Sylas Changelog Here",
        },
        Lux = {
            Version = 0.16,
            Changelog = "Lux Changelog Here",
        },
        Kassadin = {
            Version = 0.11,
            Changelog = "Kassadin Changelog Here",
        },
        Khazix = {
            Version = 0.02,
            Changelog = "Khazix Changelog Here",
        },
        Mordekaiser = {
            Version = 0.07,
            Changelog = "Mordekaiser Changelog Here",
        },
        FiddleSticks = {
            Version = 0.05,
            Changelog = "Fiddlesticks Changelog Here",
        },
        Chogath = {
            Version = 0.05,
            Changelog = "Chogath Changelog Here",
        },
        Viego = {
            Version = 0.03,
            Changelog = "Viego Changelog Here",
        },
        Leona = {
            Version = 0.06,
            Changelog = "Leona Changelog Here",
        },
        Ashe = {
            Version = 0.05,
            Changelog = "Ashe Changelog Here",
        },
        Volibear = {
            Version = 0.04,
            Changelog = "Volibear Changelog Here",
        },
        Brand = {
            Version = 0.02,
            Changelog = "Brand Changelog Here",
        },
        Evelynn = {
            Version = 0.02,
            Changelog = "Evelynn Changelog Here",
        },
        Malzahar = {
            Version = 0.1,
            Changelog = "Malzahar Changelog Here",
        },
        Riven = {
            Version = 0.05,
            Changelog = "Riven Changelog Here",
        },
        Katarina = {
            Version = 0.04,
            Changelog = "Katarina Changelog Here",
        },
        Rell = {
            Version = 0.02,
            Changelog = "Rell Changelog Here",
        },
        Soraka = {
            Version = 0.09,
            Changelog = "Soraka Changelog Here",
        },
        Zyra = {
            Version = 0.1,
            Changelog = "Zyra Changelog Here",
        },
        Rengar = {
            Version = 0.07,
            Changelog = "Rengar Changelog Here",
        },
        Fiora = {
            Version = 0.1,
            Changelog = "Fiora Changelog Here",
        },
        Aatrox = {
            Version = 0.03,
            Changelog = "Aatrox Changelog Here",
        },
        Seraphine = {
            Version = 0.06,
            Changelog = "Seraphine Changelog Here",
        },
        Hecarim = {
            Version = 0.02,
            Changelog = "Hecarim Changelog Here",
        },
        Illaoi = {
            Version = 0.03,
            Changelog = "Illaoi Changelog Here",
        },
        Lulu = {
            Version = 0.02,
            Changelog = "Lulu Changelog Here",
        },
        Velkoz = {
            Version = 0.05,
            Changelog = "Velkoz Changelog Here",
        },
        Sona = {
            Version = 0.06,
            Changelog = "Sona Changelog Here",
        },
        Kayn = {
            Version = 0.02,
            Changelog = "Kayn Changelog Here",
        },
        XinZhao = {
            Version = 0.07,
            Changelog = "XinZhao Changelog Here",
        },
        MonkeyKing = {
            Version = 0.04,
            Changelog = "MonkeyKing Changelog Here",
        },
        Renekton = {
            Version = 0.03,
            Changelog = "Renekton Changelog Here",
        },
        Kalista = {
            Version = 0.11,
            Changelog = "Kalista Changelog Here",
        },
        Shen = {
            Version = 0.02,
            Changelog = "Shen Changelog Here",
        },
        Orianna = {
            Version = 0.01,
            Changelog = "Orianna Changelog Here",
        },
        Warwick = {
            Version = 0.07,
            Changelog = "Warwick Changelog Here",
        },
        Ahri = {
            Version = 0.12,
            Changelog = "Ahri Changelog Here",
        },
        Akali = {
            Version = 0.08,
            Changelog = "Akali Changelog Here",
        },
        Ekko = {
            Version = 0.1,
            Changelog = "Ekko Changelog Here",
        },
        Diana = {
            Version = 0.03,
            Changelog = "Diana Changelog Here",
        },
        Garen = {
            Version = 0.06,
            Changelog = "Garen Changelog Here",
        },
        Caitlyn = {
            Version = 0.19,
            Changelog = "Caitlyn Changelog Here",
        },
        Karthus = {
            Version = 0.03,
            Changelog = "Karthus Changelog Here",
        },
        Tristana = {
            Version = 0.11,
            Changelog = "Tristana Changelog Here",
        },
        LeeSin = {
            Version = 0.06,
            Changelog = "LeeSin Changelog Here",
        },
        Graves = {
            Version = 0.05,
            Changelog = "Graves Changelog Here",
        },
        Azir = {
            Version = 0.03,
            Changelog = "Azir Changelog Here",
        },
        Xayah = {
            Version = 0.05,
            Changelog = "Xayah Changelog Here",
        },
        Alistar = {
            Version = 0.04,
            Changelog = "Alistar Changelog Here",
        },
        Camille = {
            Version = 0.11,
            Changelog = "Camille Changelog Here",
        },
        Kaisa = {
            Version = 0.07,
            Changelog = "Kaisa Changelog Here",
        },
        Nocturne = {
            Version = 0.05,
            Changelog = "Nocturne Changelog Here",
        },
        Zoe = {
            Version = 0.12,
            Changelog = "Zoe Changelog Here",
        },
        Cassiopeia = {
            Version = 0.12,
            Changelog = "Cassiopeia Changelog Here",
        },
        Veigar = {
            Version = 0.07,
            Changelog = "Veigar Changelog Here",
        },
        Leblanc = {
            Version = 0.03,
            Changelog = "Leblanc Changelog Here",
        },
        Anivia = {
            Version = 0.03,
            Changelog = "Anivia Changelog Here",
        },
        Qiyana = {
            Version = 0.1,
            Changelog = "Qiyana Changelog Here",
        },
        Morgana = {
            Version = 0.09,
            Changelog = "Morgana Changelog Here",
        },
        Zed = {
            Version = 0.08,
            Changelog = "Zed Changelog Here",
        },
        Malphite = {
            Version = 0.03,
            Changelog = "Malphite Changelog Here",
        },
        Thresh = {
            Version = 0.03,
            Changelog = "Thresh Changelog Here",
        },
        Syndra = {
            Version = 0.04,
            Changelog = "Syndra Changelog Here",
        },
        Blitzcrank = {
            Version = 0.04,
            Changelog = "Blitzcrank Changelog Here",
        },
        Janna = {
            Version = 0.02,
            Changelog = "Janna Changelog Here",
        },
        Karma = {
            Version = 0.03,
            Changelog = "Karma Changelog Here",
        },
        Neeko = {
            Version = 0.08,
            Changelog = "Neeko Changelog Here",
        },
        Jhin = {
            Version = 0.11,
            Changelog = "Jhin Changelog Here",
        },
    },
}

return Data