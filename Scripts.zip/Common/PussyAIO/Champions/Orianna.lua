

function LoadScript()
    Menu = MenuElement({type = MENU, id = "PussyAIO" .. myHero.charName, name = myHero.charName})
    Menu:MenuElement({name = " ", drop = {"Comming Soon"}})

end
