--[[
This is just a proof of concept script, showing how you can use missiles and particles to your advantage.
A lot of code from the internet has been copied real quick and there could be a better way to actually draw the skillshots path.
--]]

local res = Game.Resolution()

local SkillshotsMenu = MenuElement({type = MENU, id = "SkillshotsMenu", name = "Enemy Skillshot Detector", leftIcon = "http://puu.sh/tpnyM/8fd63aff9a.png"})
SkillshotsMenu:MenuElement({id = "Enabled", name = "Enabled", value = true})
SkillshotsMenu:MenuElement({id = "Transparency", name = "Drawing Transparency", value = 80, min = 10, max = 255})

local function DrawLine3D(x,y,z,a,b,c,width,col)
  local p1 = Vector(x,y,z):To2D()
  local p2 = Vector(a,b,c):To2D()
  Draw.Line(p1.x, p1.y, p2.x, p2.y, width, col)
end

local function DrawRectangleOutline(x, y, z, x1, y1, z1, width, col)
  local startPos = Vector(x,y,z)
  local endPos = Vector(x1,y1,z1)
  local c1 = startPos+Vector(Vector(endPos)-startPos):Perpendicular():Normalized()*width
  local c2 = startPos+Vector(Vector(endPos)-startPos):Perpendicular2():Normalized()*width
  local c3 = endPos+Vector(Vector(startPos)-endPos):Perpendicular():Normalized()*width
  local c4 = endPos+Vector(Vector(startPos)-endPos):Perpendicular2():Normalized()*width
  DrawLine3D(c1.x,c1.y,c1.z,c2.x,c2.y,c2.z,2,col)
  DrawLine3D(c2.x,c2.y,c2.z,c3.x,c3.y,c3.z,2,col)
  DrawLine3D(c3.x,c3.y,c3.z,c4.x,c4.y,c4.z,2,col)
  DrawLine3D(c1.x,c1.y,c1.z,c4.x,c4.y,c4.z,2,col)
end

function OnDraw()
if SkillshotsMenu.Enabled:Value() == false then return end
local drawColor = Draw.Color(SkillshotsMenu.Transparency:Value(),0xFF,0xFF,0xFF);
for i = 1, Game.MissileCount() do
	local missile = Game.Missile(i)
	if missile and (missile.missileData.owner > 0) and (missile.missileData.target == 0) and (missile.missileData.speed > 0) and (missile.missileData.width > 0) and (missile.missileData.range > 0) and missile.isEnemy and (missile.team < 300)  then
		if (res.x*2 >= missile.pos2D.x) and (res.x*-1 <= missile.pos2D.x) and (res.y*2 >= missile.pos2D.y) and (res.y*-1 <= missile.pos2D.y) then --draw skillshots close to our screen, probably we need to exclude global ultimates
			Draw.Circle(missile.pos,missile.missileData.width,drawColor);
			DrawRectangleOutline(missile.missileData.startPos.x,missile.missileData.startPos.y,missile.missileData.startPos.z,missile.missileData.endPos.x,missile.missileData.endPos.y,missile.missileData.endPos.z,missile.missileData.width,drawColor);
			end
		end
	end
--[[
for u = 1, Game.ParticleCount() do --if you want to detect ground spells such as brand W, but needs spellname database list (incl. width), since particles lack needed data
	local particle = Game.Particle(u)
	if particle and particle.name:find("Brand_Base_W_POF_tar_") then
		Draw.Circle(particle.pos,240,drawColor);
		--Draw.Text(particle.name,particle.pos2D.x,particle.pos2D.y);
		end
	end
--]]
end