require "MapPositionGOS"

local mapID = Game.mapID;
local wards = {}
local quality = 1
local safeWardSpots = {
	{ -- BLUE TOP SIDE BRUSH
		clickPosition = {x=2380.09, y=-71.24, z=11004.69},
		wardPosition  = {x=2826.47, y=-71.02, z=11221.34},
		movePosition  = {x=1774, y=52.84, z=10856}
	},
	{ -- MID TO WOLVES BLUE SIDE
		clickPosition = {x=5174.83, y=50.57, z=7119.81},
		wardPosition  = {x=4909.10, y=50.65, z=7110.90},
		movePosition  = {x=5749.25, y=51.65, z=7282.75}
	},
	{ -- TOWER TO WOLVES BLUE SIDE
		clickPosition = {x=5239.21, y=50.67, z=6944.90},
		wardPosition  = {x=4919.83, y=50.64, z=7023.80},
		movePosition  = {x=5574, y=51.74, z=6458}
	},
	{ -- RED BLUE SIDE
		clickPosition = {x=8463.64, y=50.60, z=4658.71},
		wardPosition  = {x=8512.29, y=51.30, z=4745.90},
		movePosition  = {x=8022, y=53.72, z=4258}
	},
	{    -- DRAGON -> BOT BUSH
		clickPosition = {x=10301.03, y=49.03, z=3333.20},
		wardPosition  = {x=10322.94, y=49.03, z=3244.38},
		movePosition  = {x=10072, y=-71.24, z=3908}
	},
	{    -- BARON -> TOP BUSH
		clickPosition = {x=4633.83, y=50.51, z=11354.40},
		wardPosition  = {x=4524.69, y=53.25, z=11515.21},
		movePosition  = {x=4824, y=-71.24, z=10906}
	},
	{    -- RED -> RED SIDE
		clickPosition = {x=6360.12, y=52.61, z=10362.71},
		wardPosition  = {x=6269.35, y=53.72, z=10306.69},
		movePosition  = {x=6824, y=56, z=10656}
	},
	{    -- TOWER TO WOLVES -> RED SIDE
		clickPosition = {x=9586.57, y=59.62, z=8020.29},
		wardPosition  = {x=9871.77, y=51.47, z=8014.44},
		movePosition  = {x=9122, y=53.74, z=8356}
	},
	{    -- MID TO WOLVES -> RED SIDE
		clickPosition = {x=9647.62, y=51.31, z=7889.96},
		wardPosition  = {x=9874.42, y=51.50, z=7969.29},
		movePosition  = {x=9122, y=52.60, z=7606}
	},
	{    -- RED BOT SIDE BUSH
		clickPosition = {x=12427.00, y=-35.46, z=3984.26},
		wardPosition  = {x=11975.34, y=66.37, z=3927.68},
		movePosition  = {x=13022, y=51.37, z=3808}
	}
}



local WardAwareness = MenuElement({type = MENU, id = "WardAwareness", name = "Ward Awareness", leftIcon = "http://ddragon.leagueoflegends.com/cdn/6.12.1/img/item/2050.png"})
WardAwareness:MenuElement({id = "Enabled", name = "Enabled", value = true})
WardAwareness:MenuElement({id = "Quality", name = "Ward Vision Quality", value = quality, min = 8, max = 72, step = 4, callback = function(var) if quality ~= var then quality = var; wards = {}; collectgarbage(); end end})
WardAwareness:MenuElement({type = MENU, id = "VisionWard", name = "Vision Wards", leftIcon = "http://ddragon.leagueoflegends.com/cdn/6.12.1/img/item/2043.png"})
WardAwareness.VisionWard:MenuElement({id = "ScreenDisplay", name = "Show On Screen", value = true, leftIcon = "http://puu.sh/rGpSj/e92234a9af.png"})
WardAwareness.VisionWard:MenuElement({id = "OwnerDisplay", name = "Show Ward Owner", value = true})
WardAwareness.VisionWard:MenuElement({id = "VisionDisplay", name = "Show Ward Vision", value = true})
WardAwareness.VisionWard:MenuElement({id = "MinimapDisplay", name = "Show On Minimap", value = true, leftIcon = "http://puu.sh/rGpKK/e60ba3daa3.png"})
WardAwareness:MenuElement({type = MENU, id = "SightWard", name = "Sight Wards", leftIcon = "http://ddragon.leagueoflegends.com/cdn/6.12.1/img/item/2049.png"})
WardAwareness.SightWard:MenuElement({id = "ScreenDisplay", name = "Show On Screen", value = true, leftIcon = "http://puu.sh/rGpSj/e92234a9af.png"})
WardAwareness.SightWard:MenuElement({id = "OwnerDisplay", name = "Show Ward Owner", value = true})
WardAwareness.SightWard:MenuElement({id = "TimerDisplay", name = "Show Ward Timer", value = true})
WardAwareness.SightWard:MenuElement({id = "VisionDisplay", name = "Show Ward Vision", value = true})
WardAwareness.SightWard:MenuElement({id = "MinimapDisplay", name = "Show On Minimap", value = true, leftIcon = "http://puu.sh/rGpKK/e60ba3daa3.png"})
WardAwareness:MenuElement({type = MENU, id = "Trinket", name = "Warding Trinket", leftIcon = "http://ddragon.leagueoflegends.com/cdn/6.12.1/img/item/3340.png"})
WardAwareness.Trinket:MenuElement({id = "ScreenDisplay", name = "Show On Screen", value = true, leftIcon = "http://puu.sh/rGpSj/e92234a9af.png"})
WardAwareness.Trinket:MenuElement({id = "OwnerDisplay", name = "Show Ward Owner", value = true})
WardAwareness.Trinket:MenuElement({id = "TimerDisplay", name = "Show Ward Timer", value = true})
WardAwareness.Trinket:MenuElement({id = "VisionDisplay", name = "Show Ward Vision", value = true})
WardAwareness.Trinket:MenuElement({id = "MinimapDisplay", name = "Show On Minimap", value = true, leftIcon = "http://puu.sh/rGpKK/e60ba3daa3.png"})
WardAwareness:MenuElement({type = MENU, id = "Farsight", name = "Farsight Trinket", leftIcon = "http://ddragon.leagueoflegends.com/cdn/6.12.1/img/item/3363.png"})
WardAwareness.Farsight:MenuElement({id = "ScreenDisplay", name = "Show On Screen", value = true, leftIcon = "http://puu.sh/rGpSj/e92234a9af.png"})
WardAwareness.Farsight:MenuElement({id = "OwnerDisplay", name = "Show Ward Owner", value = true})
WardAwareness.Farsight:MenuElement({id = "VisionDisplay", name = "Show Ward Vision", value = true})
WardAwareness.Farsight:MenuElement({id = "MinimapDisplay", name = "Show On Minimap", value = true, leftIcon = "http://puu.sh/rGpKK/e60ba3daa3.png"})
WardAwareness:MenuElement({type = MENU, id = "WardPlacing", name = "Safe Warding Spots", leftIcon = "http://ddragon.leagueoflegends.com/cdn/6.19.1/img/item/3187.png"})
WardAwareness.WardPlacing:MenuElement({id = "ShowSpots", name = "Enabled", value = true})
WardAwareness.WardPlacing:MenuElement({id = "Sens", name = "Distance Fade", value = 400, min = 100, max = 1000})


local function IntegerToMinSec(i)
	local m, s = math.floor(i/60), (i%60)
	return (m < 10 and 0 or "")..m..":"..(s < 10 and 0 or "")..s
end

local WardColors = {SightWard = Draw.Color(255,0,255,0), VisionWard = Draw.Color(0xFF,0xAA,0,0xAA), Trinket = Draw.Color(0xFF,0xAA,0xAA,0), Farsight = Draw.Color(0xFF,00,0xBF,0xFF)}


local function DrawWard(type, ward)
	if not WardAwareness[type] then
		return
	end
	if ward.pos2D.onScreen then
		if WardAwareness[type].ScreenDisplay:Value() then
			Draw.Circle(ward.pos,70,2,WardColors[type]);
		end
		if WardAwareness[type].OwnerDisplay:Value() then
			if ward.owner ~= nil then
				Draw.Text(ward.owner.charName,16,ward.pos2D.x,ward.pos2D.y,WardColors[type]);
			end
		end
		if WardAwareness[type].TimerDisplay and WardAwareness[type].TimerDisplay:Value() then
			for i = 1, ward.buffCount do
				local buff = ward:GetBuff(i);
				if (buff.count > 0) and (buff.expireTime > buff.startTime) then --(buff.type == 6) and //removed bufftype as it's incorrect now, buff types changed
					local wardLife = buff.expireTime - Game.Timer();
					Draw.Text(IntegerToMinSec(math.ceil(wardLife)),16,ward.pos2D.x,ward.pos2D.y-14,WardColors[type]);
					break;
					end
				end
			--Draw.Text(IntegerToMinSec(math.ceil(wardLife)),16,ward.pos2D.x,ward.pos2D.y-14,WardColors[type]);
		end
	end
	if WardAwareness[type].MinimapDisplay:Value() then
		Draw.CircleMinimap(ward.pos,200,3,WardColors[type]);
	end
end


local function DrawLine3D(x,y,z,a,b,c,width,col)
	local p1 = Vector(x,y,z):To2D()
	local p2 = Vector(a,b,c):To2D()
	Draw.Line(p1.x, p1.y, p2.x, p2.y, width, col)
end


local function GetDrawPoints2(index)
	local wardVector = {x = wards[index][1], y = wards[index][2], z = wards[index][3]}
	local alpha = 0
	for i = 1, WardAwareness.Quality:Value() do
		alpha = alpha + 360 / WardAwareness.Quality:Value()
		wards[index][7+i] = {}
		local a = 0.1
		wards[index][7 + i][1] = wardVector.x 
		wards[index][7 + i][2] = wardVector.y
		wards[index][7 + i][3] = wardVector.z
		while (not MapPosition:inWall(Vector(wards[index][7 + i][1],wards[index][7 + i][2],wards[index][7 + i][3]))) and a < 0.9 do
			a = a + 0.025
			local vc = Vector(wards[index][6] * math.sin(alpha / 360 * 6.28), 0, wards[index][6] * math.cos(alpha / 360 * 6.28)):Normalized() * wards[index][6] * a
			wards[index][7 + i][1] = wardVector.x + vc.x
			wards[index][7 + i][2] = wardVector.y
			wards[index][7 + i][3] = wardVector.z + vc.z
		end
	end
end

local function DrawWards()
	for num, ward in pairs(wards) do
		local i = 1
		while (ward[7+i]) do
			if ward[8+i] then
				DrawLine3D(ward[7+i][1], ward[7+i][2], ward[7+i][3], ward[8+i][1], ward[8+i][2], ward[8+i][3], 3, ward[5])
			else
				DrawLine3D(ward[7+i][1], ward[7+i][2], ward[7+i][3], ward[8][1], ward[8][2], ward[8][3], 3, ward[5])
			end
			i = i + 1
		end
	end
end


local function RemoveInvalidWards()
for num, ward in pairs(wards) do
	if ward[4] then
		if ward[4] + 200 < GetTickCount() then -- 200 milliseconds should be enough
			wards[num] = nil
			collectgarbage()
			end
		end
	end
end



function OnDraw()
if WardAwareness.Enabled:Value() then
local currentTick = GetTickCount();
for i = 1, Game.WardCount() do
	local ward = Game.Ward(i);
	if ward.valid and ward.isEnemy then  --VisionWard became JammerDevice wtf xD, good that it is still 4hp
		DrawWard(ward.maxHealth == 4 and "VisionWard" or ward.maxHealth == 3 and (ward.maxMana == 150 and "SightWard" or "Trinket") or ward.maxHealth == 1 and "Farsight" or "WTFISTHISWARD", ward)
		if not wards[ward.networkID] then --we add the ward for the first time to the struct
			if ward.maxHealth == 4 and WardAwareness.VisionWard.VisionDisplay:Value() then
				wards[ward.networkID] = { ward.pos.x, ward.pos.y, ward.pos.z, currentTick, Draw.Color(0x70,0xAA,0,0xAA), 1100 }
				GetDrawPoints2(ward.networkID)
				end
			if ward.maxHealth == 3 then
				if ward.maxMana == 150 and WardAwareness.SightWard.VisionDisplay:Value() then --the good old sight ward 2:30
					wards[ward.networkID] = { ward.pos.x, ward.pos.y, ward.pos.z, currentTick, Draw.Color(0x70,0,0xFF,0), 1100 }
					GetDrawPoints2(ward.networkID)
					elseif  WardAwareness.Trinket.VisionDisplay:Value() then --else it is supposed to be trinket ward
					wards[ward.networkID] = { ward.pos.x, ward.pos.y, ward.pos.z, currentTick, Draw.Color(0x70,0xAA,0xAA,0), 1100 }
					GetDrawPoints2(ward.networkID)
					end
				end
			if ward.maxHealth == 1 and WardAwareness.Farsight.VisionDisplay:Value() then
				wards[ward.networkID] = { ward.pos.x, ward.pos.y, ward.pos.z, currentTick, Draw.Color(0x70,0,0xBF,0xFF), 500 }
				GetDrawPoints2(ward.networkID)
				end
			else --keep updating ward existance
			if ward.maxHealth == 4 and WardAwareness.VisionWard.VisionDisplay:Value() then
				wards[ward.networkID][4] = currentTick;
				end
			if ward.maxHealth == 3 then
				if ward.maxMana == 150 and WardAwareness.SightWard.VisionDisplay:Value() then --the good old sight ward 2:30
					wards[ward.networkID][4] = currentTick;
					elseif  WardAwareness.Trinket.VisionDisplay:Value() then --else it is supposed to be trinket ward
					wards[ward.networkID][4] = currentTick;
					end
				end
			if ward.maxHealth == 1 and WardAwareness.Farsight.VisionDisplay:Value() then
				wards[ward.networkID][4] = currentTick;
				end
			end
		end
	end
end
if WardAwareness.Enabled:Value() then
	DrawWards();
	if mapID == SUMMONERS_RIFT then
		if WardAwareness.WardPlacing.ShowSpots:Value() then
			for i,wardSpot in pairs(safeWardSpots) do
				local mpVec = Vector(wardSpot.movePosition);
				local spotDist = mpVec:DistanceTo();
				local alpha = spotDist < 1 and 255 or (255 - 255 * (spotDist-1) / WardAwareness.WardPlacing.Sens:Value())
				if (spotDist < WardAwareness.WardPlacing.Sens:Value()) and (spotDist > 70) then
					Draw.Circle(wardSpot.movePosition.x, wardSpot.movePosition.y, wardSpot.movePosition.z,100, 0, Draw.Color(alpha, 255, 255, 255)); 
					elseif (spotDist < 70) then
					Draw.Circle(wardSpot.movePosition.x, wardSpot.movePosition.y, wardSpot.movePosition.z,100, 0, Draw.Color(0xFF00FF00)); 
					local clickDist = mousePos:DistanceTo(wardSpot.clickPosition);
					if clickDist > 30 then
						Draw.Circle(wardSpot.clickPosition.x, wardSpot.clickPosition.y, wardSpot.clickPosition.z,30, 0, Draw.Color(0xFFFFFFFF)); 
						else
						Draw.Circle(wardSpot.clickPosition.x, wardSpot.clickPosition.y, wardSpot.clickPosition.z,30, 0, Draw.Color(0xFF00FF00)); 
						Draw.Circle(wardSpot.wardPosition.x, wardSpot.wardPosition.y, wardSpot.wardPosition.z,30, 0, Draw.Color(0xFF00FF00));
						local magneticWardSpotVector = Vector(wardSpot.movePosition.x, wardSpot.movePosition.y, wardSpot.movePosition.z)
						local wardPositionVector = Vector(wardSpot.wardPosition.x, wardSpot.wardPosition.y, wardSpot.wardPosition.z)
						local directionVector = (wardPositionVector-magneticWardSpotVector):Normalized()
						local line1Start = magneticWardSpotVector + directionVector:Perpendicular() * 100
						local line1End = wardPositionVector + directionVector:Perpendicular() * 30
						local line2Start = magneticWardSpotVector + directionVector:Perpendicular2() * 100
						local line2End = wardPositionVector + directionVector:Perpendicular2() * 30
						local p1 = line1Start:To2D(); 
						local p2 = line1End:To2D(); 
						local p3 = line2Start:To2D(); 
						local p4 = line2End:To2D(); 
						Draw.Line(p1.x, p1.y, p2.x, p2.y, 1, Draw.Color(0xFF00FF00))
						Draw.Line(p3.x, p3.y, p4.x, p4.y, 1, Draw.Color(0xFF00FF00))
						end
					end
				end
			end
		end
	end
end

function OnTick()
RemoveInvalidWards();
end


--PrintChat("Ward awareness by WhiteHat loaded.")